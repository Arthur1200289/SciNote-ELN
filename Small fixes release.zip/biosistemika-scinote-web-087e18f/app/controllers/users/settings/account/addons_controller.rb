module Users
  module Settings
    module Account
      class AddonsController < ApplicationController
        layout 'fluid'
      end
    end
  end
end
