module ClientApi
  class SettingsController < ApplicationController
    layout 'application_client_api'

    def index; end
  end
end
