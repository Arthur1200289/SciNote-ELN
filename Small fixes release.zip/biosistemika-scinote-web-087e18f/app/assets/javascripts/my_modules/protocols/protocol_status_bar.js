$(function(){
  $('body').tooltip( {selector: '[data-toggle=tooltip]'} );
});
$(function () {
  $('[data-toggle="popover"]').popover();
});