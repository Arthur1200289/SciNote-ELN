# frozen_string_literal: true

class ApplicationSettings < Settings
end
