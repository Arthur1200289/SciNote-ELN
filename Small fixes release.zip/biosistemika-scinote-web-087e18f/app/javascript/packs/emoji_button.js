global.twemoji = require('twemoji').default;
global.twemoji.base = '/images/twemoji/';
global.twemoji.size = '24x24';
global.EmojiButton = require('@joeattardi/emoji-button/dist/index');
