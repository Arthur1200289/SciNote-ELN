global.tui = {};
global.tui.usageStatistics = false;
require('tui-code-snippet');

require('tui-color-picker');

global.tui.ImageEditor = require('tui-image-editor');
