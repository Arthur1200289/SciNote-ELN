// After upgrading webpacker to 4.0.0 this causes issues.
// When reviving the project it will have to be changed anyway

//import "babel-polyfill";
//import "intl";
//import "intl/locale-data/jsonp/en-US.js"
//import React from "react";
//import ReactDOM from "react-dom";
//import App from "../src/";

//document.addEventListener("DOMContentLoaded", () => {
  //ReactDOM.render(<App />, document.getElementById("root"));
//});
